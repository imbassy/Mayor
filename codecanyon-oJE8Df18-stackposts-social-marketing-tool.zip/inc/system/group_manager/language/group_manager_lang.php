<?php
$lang["Success"] = "Success";
$lang["Group manager"] = "Group manager";
$lang["Name"] = "Name";
$lang["Please select less than a profile"] = "Please select less than a profile";
$lang["Please select an item to delete"] = "Please select an item to delete";
$lang["Search"] = "Search";
$lang["Are you sure to delete this items?"] = "Are you sure to delete this items?";
$lang["Delete"] = "Delete";
$lang["Groups"] = "Groups";
$lang["Add new"] = "Add new";
$lang["Group name"] = "Group name";
$lang["Drag and drop to right to select and to left to unselect"] = "Drag and drop to right to select and to left to unselect";
$lang["All accounts"] = "All accounts";
$lang["Selected accounts"] = "Selected accounts";
$lang["Save"] = "Save";
$lang["Cancel"] = "Cancel"; 