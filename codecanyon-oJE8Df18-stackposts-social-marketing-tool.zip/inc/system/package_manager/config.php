<?php
return [
    'id' => 'package_manager',
    'name' => 'Package manager',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-cubes',
    'color' => '',
    'menu' => [
        'tab' => 5,
        'position' => 4000,
        'name' => 'Package manager'
    ],
    'css' => [
        'assets/css/package_manager.css'
    ]
];