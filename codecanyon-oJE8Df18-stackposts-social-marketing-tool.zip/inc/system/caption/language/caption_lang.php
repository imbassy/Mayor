<?php
$lang["Success"] = "Success";
$lang["Caption"] = "Caption";
$lang["Add new"] = "Add new";
$lang["Please select an item to delete"] = "Please select an item to delete";
$lang["Are you sure to delete this items?"] = "Are you sure to delete this items?";
$lang["Delete"] = "Delete";
$lang["Search"] = "Search";
$lang["List captions"] = "List captions";
$lang["Update"] = "Update";
$lang["Back"] = "Back";
$lang["Name"] = "Name";
$lang["Submit"] = "Submit";
$lang["xxx"] = "xxx";
$lang["xxx"] = "xxx";