<?php
$lang["Success"] = "Success";
$lang["Cronjobs"] = "Cronjobs";