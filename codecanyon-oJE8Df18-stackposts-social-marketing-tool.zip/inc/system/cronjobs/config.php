<?php
return [
    'id' => 'cronjobs',
    'name' => 'Cronjobs',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-sync',
    'color' => '',
    'menu' => [
        'tab' => 6,
    	'position' => 1000,
    	'name' => 'Cronjobs',
    ]
];