<?php
$lang["Success"] = "Success";
$lang["Others"] = "Others";
$lang["Enable HTTPS"] = "Enable HTTPS";
$lang["Enable"] = "Enable";
$lang["Disable"] = "Disable";
$lang["Please make sure your server supported SSL before turn on it"] = "Please make sure your server supported SSL before turn on it";
$lang["Embed code"] = "Embed code";
$lang["Terms of Services"] = "Terms of Services";
$lang["Privacy Policy"] = "Privacy Policy";
$lang["Submit"] = "Submit";