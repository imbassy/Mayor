<?php
$lang["Success"] = "Success";
$lang["Please select an item to delete"] = "Please select an item to delete";
$lang["Delete failed"] = "Delete failed";
$lang["Your package Your package cannot add accounts"] = "Your package Your package cannot add accounts";
$lang["Your package can only add up to %s accounts on each social network"] = "Your package can only add up to %s accounts on each social network";
$lang["Allow add profiles for"] = "Allow add profiles for"; 
$lang["Are you sure to delete this items?"] = "Are you sure to delete this items?"; 
$lang["Account manager"] = "Account manager"; 
$lang["Relogin required"] = "Relogin required"; 
$lang["Add account"] = "Add account"; 
$lang["Check All"] = "Check All"; 
