<div class="row">
	<?php $CI =& get_instance(); _e( isset($CI->account_manager)?$CI->account_manager:"" , false)?>
</div>