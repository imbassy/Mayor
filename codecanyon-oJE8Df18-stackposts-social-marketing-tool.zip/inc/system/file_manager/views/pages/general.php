<form action="" class="fm-form" method="POST">
	<div class="fm-content row ajax-load-files" data-action="<?php _e( get_module_url('ajax_load') )?>" data-page="0" data-type="scroll" data-scroll=".file-manager .column-two">
		<div class="fm-loading">
			<img src="<?php _e( get_module_path($this, "assets/img/loading.gif") )?>">
		</div>
	</div>
</form>

<style type="text/css">
.fancybox-toolbar{
	opacity: 1;
	visibility: visible;
}
</style>