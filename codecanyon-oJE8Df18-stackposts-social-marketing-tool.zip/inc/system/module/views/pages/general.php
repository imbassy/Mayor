<div class="wrap-m h-100">
	<div class="empty">
		<div class="icon"></div>
	</div>
</div>