<div class="item d-none d-sm-block">
    <a href="<?php _e( get_url("module") )?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php _e( $module_name )?>"><i class="<?php _e( $module_icon )?>"></i></a>
</div>