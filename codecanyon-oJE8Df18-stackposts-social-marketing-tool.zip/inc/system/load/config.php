<?php
return [
    'id' => 'load',
    'name' => 'Load',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-tasks',
    'color' => '',
    'pulic' => true
];